# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\Hasan\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\Hasan\\Downloads\\AirCanvas-v1.0.0-fixed-latest" PROJECT_DIR)

set(FLUTTER_VERSION "1.1.0+2" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 2 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\Hasan\\flutter"
  "PROJECT_DIR=C:\\Users\\Hasan\\Downloads\\AirCanvas-v1.0.0-fixed-latest"
  "FLUTTER_ROOT=C:\\Users\\Hasan\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\Hasan\\Downloads\\AirCanvas-v1.0.0-fixed-latest\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\Hasan\\Downloads\\AirCanvas-v1.0.0-fixed-latest"
  "FLUTTER_TARGET=lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDQuNw==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ODRmYzVjYmIyMg==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NjljOGM2MTc5Mg==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMi4y"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=true"
  "PACKAGE_CONFIG=C:\\Users\\Hasan\\Downloads\\AirCanvas-v1.0.0-fixed-latest\\.dart_tool\\package_config.json"
)
